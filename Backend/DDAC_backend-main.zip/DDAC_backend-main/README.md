# DDAC_backend

This assignment is for `DESIGNING AND DEVELOPING APPLICATIONS ON THE CLOUD` in ***Asia Pacific University of Technology and Innovation*** 2023. 

## Authors
1. Wong Tze Byng
2. Ghassan Y J Rashwan
3. Cristina Mahanta
4. Oumadevi Sevanandee
5. Hussein Abdullah Mohammed Ba Ragaa

## Installation

Move the current location to the desired location:

``` bash
cd <path to your desired location>
```

To install the GitHub repo:

``` bash
git clone https://github.com/tzubindev/DDAC_backend.git
```

## Frontend Installation

Frontend GitHub repo link:

``` bash
https://github.com/GhassanYJR/DDAC_frontend.git
```
